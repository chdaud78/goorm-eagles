import { Router } from "express";
import { requireAuth } from "../middleware/auth.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { User } from "../models/User.js";
import argon2 from "argon2";

const router = Router();

// 내 정보 조회
router.get(
  "/me",
  requireAuth,
  asyncHandler(async (req, res) => {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ message: "Not found" });
    res.json(user.toSafe());
  })
);

// 프로필 수정
router.patch(
  "/me",
  requireAuth,
  asyncHandler(async (req, res) => {
    const { name } = req.body || {};
    const user = await User.findByIdAndUpdate(
      req.user.id,
      { $set: { name } },
      { new: true }
    );
    res.json(user.toSafe());
  })
);

// 비밀번호 변경
router.post(
  "/me/change-password",
  requireAuth,
  asyncHandler(async (req, res) => {
    const { currentPassword, newPassword } = req.body || {};
    if (!currentPassword || !newPassword) return res.status(400).json({ message: "currentPassword & newPassword required" });

    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ message: "Not found" });

    const ok = await argon2.verify(user.passwordHash, currentPassword);
    if (!ok) return res.status(401).json({ message: "Invalid credentials" });

    user.passwordHash = await argon2.hash(newPassword);
    await user.save();

    res.json({ ok: true });
  })
);

export default router;
